<?php


use Stichoza\GoogleTranslate\GoogleTranslate;

require('vendor/autoload.php');

$tr = new GoogleTranslate(); // Translates to 'en' from auto-detected language by default
$tr->setSource(); // Detect language automatically
$tr->setTarget('ka'); // Translate to Georgian
$array = [
    'title'=>'',
    'desc' => ''
]; 
echo $text = $tr->translate('hi $$$ how are you I am fine');